from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import csv
import time

options = webdriver.ChromeOptions()
options.add_experimental_option('detach', True)
driver = webdriver.Chrome(executable_path='C:/Users/12848/Desktop/spider/chromedriver.exe', options=options)


if __name__ == '__main__':
    f = open('data.csv', mode='w', encoding='UTF-8', newline='')
    csv_writer = csv.DictWriter(f,  fieldnames={
        '品名', '价格', '链接'
    })
    # 写入表头
    csv_writer.writeheader()
    driver.get('https://www.jd.com')
    # 输入关键字
    driver.find_element_by_css_selector('#key').send_keys('笔记本')
    # 按下搜索按钮
    actions = ActionChains(driver)
    button = driver.find_element_by_css_selector('.button')
    actions.click_and_hold(button).perform()
    actions.release().perform()

    # 设置延时等待，确保网页内容加载完毕
    # 若网页加载完毕可以立即执行后续代码
    # driver.implicitly_wait(10)

    # 下滚到网页最底部
    for i in range(10):
        driver.execute_script(f'document.documentElement.scrollTop={(i+1)*1000}')
    # 这里强制延长睡眠时间来对抗懒加载，也可也用显示延时等待来完成
    time.sleep(10)

    # 抓取商品名称
    item_list = driver.find_elements_by_css_selector('.gl-item')
    # 提取列表中的元素
    for li in item_list:
        # 提取内容
        title = li.find_element_by_css_selector('.p-name em').text
        price = li.find_element_by_css_selector('.p-price i').text
        href = li.find_element_by_css_selector('.p-name a').get_attribute('href')
        dic = {
            '品名':title,
            '价格':price,
            '链接':href
        }
        csv_writer.writerow(dic)
